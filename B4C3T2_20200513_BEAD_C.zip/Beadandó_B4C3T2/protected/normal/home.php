<?php 
	$query = "SELECT * FROM cocktails ORDER BY id";
	require_once DATABASE_CONTROLLER;
	$cocktails = getList($query);
?>
<?php if(count($cocktails) <= 0) : ?>
		<h1>No cocktails found in the database</h1>
	<?php else : ?>
		<table>
			<thead>
				<tr>
					<th scope="col">&nbsp;&nbsp;#</th>
					<th scope="col">Name</th>
					<th scope="col">Base spirit</th>
					<th scope="col">Alcohol content</th>
					<th scope="col">Ingredients</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 0; ?>
				<?php foreach ($cocktails as $c) : ?>
					<?php $i++; ?>
					<tr>
						<td scope="row">&nbsp;&nbsp;<?=$i ?></td>
						<td><a href="index.php?P=profile&c=<?=$c['id'] ?>"><?=$c['name'] ?></a></td>
						<td><?=$c['base_spirit'] == 0 ? 'Rum' : ($c['base_spirit'] == 1 ? 'Vodka' : 'Tequila') ?></td>
						<td><?=$c['alcohol_content'] ?></td>
						<td><?=$c['ingredients'] ?></td>
					</tr>
				<?php endforeach;?>
			</tbody>
		</table>
	<?php endif; ?>