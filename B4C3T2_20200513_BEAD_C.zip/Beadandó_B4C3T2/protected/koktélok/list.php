<?php if(!isset($_SESSION['permission']) || $_SESSION['permission'] < 1) : ?>
	<h1>Page access is forbidden!</h1>
<?php else : ?>
<?php 
	if(array_key_exists('d', $_GET) && !empty($_GET['d'])) {
		$query = "DELETE FROM cocktails WHERE id = :id";
		$params = [':id' => $_GET['d']];
		require_once DATABASE_CONTROLLER;
		if(!executeDML($query, $params)) {
			echo "Error during deleting!";
		}
	}
?>
<?php 
	$query = "SELECT * FROM cocktails ORDER BY id";
	require_once DATABASE_CONTROLLER;
	$cocktails = getList($query);
?>
	<?php if(count($cocktails) <= 0) : ?>
		<h1>No cocktails found in the database</h1>
	<?php else : ?>
		<table>
			<div class="tablefont">
			<thead>
				<tr>
					<th scope="col">&nbsp;&nbsp;#</th>
					<th scope="col">Name</th>
					<th scope="col">Base spirit</th>
					<th scope="col">Alcohol content</th>
					<th scope="col">Ingredients</th>
					<th scope="col">Edit</th>
					<th scope="col">Delete</th>
					<th scope="col">Comments</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 0; ?>
				<?php foreach ($cocktails as $c) : ?>
					<?php $i++; ?>
					<tr>
						<td scope="row">&nbsp;&nbsp;<?=$i ?></td>
						<td><a href="index.php?P=profile&c=<?=$c['id'] ?>"><?=$c['name'] ?></a></td>
						<td><?=$c['base_spirit'] == 0 ? 'Rum' : ($c['base_spirit'] == 1 ? 'Vodka' : 'Tequila') ?></td>
						<td><?=$c['alcohol_content'] ?></td>
						<td><?=$c['ingredients'] ?></td>
						<td><a href="index.php?P=edit_cocktail&c=<?=$c['id'] ?>">
							<svg class="bi bi-pencil-square" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  								<path d="M15.502 1.94a.5.5 0 010 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 01.707 0l1.293 1.293zm-1.75 2.456l-2-2L4.939 9.21a.5.5 0 00-.121.196l-.805 2.414a.25.25 0 00.316.316l2.414-.805a.5.5 0 00.196-.12l6.813-6.814z"/>
  								<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 002.5 15h11a1.5 1.5 0 001.5-1.5v-6a.5.5 0 00-1 0v6a.5.5 0 01-.5.5h-11a.5.5 0 01-.5-.5v-11a.5.5 0 01.5-.5H9a.5.5 0 000-1H2.5A1.5 1.5 0 001 2.5v11z" clip-rule="evenodd"/>
							</svg>
						</a></td>
						<td><a href="?P=list_cocktails&d=<?=$c['id'] ?>">
							<svg class="bi bi-trash" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  								<path d="M5.5 5.5A.5.5 0 016 6v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm2.5 0a.5.5 0 01.5.5v6a.5.5 0 01-1 0V6a.5.5 0 01.5-.5zm3 .5a.5.5 0 00-1 0v6a.5.5 0 001 0V6z"/>
  								<path fill-rule="evenodd" d="M14.5 3a1 1 0 01-1 1H13v9a2 2 0 01-2 2H5a2 2 0 01-2-2V4h-.5a1 1 0 01-1-1V2a1 1 0 011-1H6a1 1 0 011-1h2a1 1 0 011 1h3.5a1 1 0 011 1v1zM4.118 4L4 4.059V13a1 1 0 001 1h6a1 1 0 001-1V4.059L11.882 4H4.118zM2.5 3V2h11v1h-11z" clip-rule="evenodd"/>
							</svg>
						</a></td>
						<td><a href="?P=comments_cocktail&c=<?=$c['id'] ?>">
							<svg class="bi bi-chat-dots" width="1em" height="1em" viewBox="0 0 16 16" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
  								<path fill-rule="evenodd" d="M2.678 11.894a1 1 0 01.287.801 10.97 10.97 0 01-.398 2c1.395-.323 2.247-.697 2.634-.893a1 1 0 01.71-.074A8.06 8.06 0 008 14c3.996 0 7-2.807 7-6 0-3.192-3.004-6-7-6S1 4.808 1 8c0 1.468.617 2.83 1.678 3.894zm-.493 3.905a21.682 21.682 0 01-.713.129c-.2.032-.352-.176-.273-.362a9.68 9.68 0 00.244-.637l.003-.01c.248-.72.45-1.548.524-2.319C.743 11.37 0 9.76 0 8c0-3.866 3.582-7 8-7s8 3.134 8 7-3.582 7-8 7a9.06 9.06 0 01-2.347-.306c-.52.263-1.639.742-3.468 1.105z" clip-rule="evenodd"/>
  								<path d="M5 8a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0zm4 0a1 1 0 11-2 0 1 1 0 012 0z"/>
							</svg>
						</a></td>
					</tr>
				<?php endforeach;?>
			</tbody>
			</div>
		</table>
	<?php endif; ?>
<?php endif; ?>