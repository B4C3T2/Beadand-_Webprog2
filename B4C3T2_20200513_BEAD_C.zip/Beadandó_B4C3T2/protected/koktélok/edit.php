<?php if(!isset($_SESSION['permission']) || $_SESSION['permission'] < 2) : ?>
	<h1>You don't have the permission to do that!</h1>
<?php else :
	if(!array_key_exists('c', $_GET) || empty($_GET['c'])) : 
		header('Location: index.php');
	else: 

	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['editCocktail'])) {
	$postData = [
		'id' => $_POST['cocktailid'],
		'name' => $_POST['name'],
		'base_spirit' => $_POST['base_spirit'],
		'alcohol_content' => $_POST['alcohol_content'],
		'ingredients' => $_POST['ingredients'],
		'img' => $_POST['img']
	];
	if($postData['id'] != $_GET['c']) {
		echo "Error during identifying!";
	} else {
		if(empty($postData['name']) || $postData['base_spirit'] < 0 && $postData['base_spirit'] > 2|| empty($postData['alcohol_content']) || empty($postData['ingredients'])) {
			echo "Missing datas!";
		} else {
			$query = "UPDATE cocktails SET name = :name, base_spirit = :base_spirit, alcohol_content = :alcohol_content, ingredients= :ingredients, img = :img WHERE id = :id";
			$params = [
				':name' => $postData['name'],
				':base_spirit' => $postData['base_spirit'],
				':alcohol_content' => $postData['alcohol_content'],
				':ingredients' => $postData['ingredients'],
				':id' => $postData['id'],
				':img' => $postData['img']
			];
			require_once DATABASE_CONTROLLER;
			if(!executeDML($query, $params)) {
				echo "Error during editing!";
			} header('Location: ?P=list_cocktails');
		}
	}
}

	$query = "SELECT * FROM cocktails WHERE id = :id";
	$params = [':id' => $_GET['c']];
	require_once DATABASE_CONTROLLER;
	$cocktail = getRecord($query, $params);
	if(empty($cocktail)) :
		header('Location: index.php');
		else : ?>
			<form method="post">
			<input type="hidden" name="cocktailid" value="<?=$cocktail['id'] ?>">
		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailName">Name</label>
				<input type="text" class="form-control" id="cocktailName" name="name" value="<?=$cocktail['name']?>">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
		    	<label for="cocktailBasespirit">Base spirit</label>
		    	<select class="form-control" id="cocktailBasespirit" name="base_spirit">
		      		<option value="0" <?=$cocktail['base_spirit'] == 0 ? 'selected' : '' ?> >Rum</option>
		      		<option value="1" <?=$cocktail['base_spirit'] == 1 ? 'selected' : '' ?> >Vodka</option>
		      		<option value="2" <?=$cocktail['base_spirit'] == 2 ? 'selected' : '' ?> >Tequila</option>
		    	</select>
		  	</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailAlcoholcontent">Alcohol content</label>
				<input type="text" class="form-control" id="cocktailAlcoholcontent" name="alcohol_content" value="<?=$cocktail['alcohol_content']?>">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailIngredients">Ingredients</label>
				<input type="text" class="form-control" id="cocktailIngredients" name="ingredients" value="<?=$cocktail['ingredients']?>">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailImg">Image web url</label>
				<input type="text" class="form-control" id="cocktailImg" name="img" value="<?=$cocktail['img']?>">
			</div>
		</div>

		<button type="submit" class="btn btn-primary" name="editCocktail">Save</button>
</form>
		<?php endif;
	endif;
endif;
?>