<div class="profile">
<?php
if(array_key_exists('c', $_GET) && !empty($_GET['c'])) {
        $query = "SELECT * FROM cocktails";
        $params = [':id' => $_GET['c']];
        require_once DATABASE_CONTROLLER;
        if(!executeDML($query, $params)) { 
            echo "Error during opening cocktail profile!";
        }
        $list = getList($query);
    } 
?>

<?php $i = 0; ?>
<?php foreach ($list as $item) : ?>
    <?php $i++; ?>
    <?php if(array_key_exists('c', $_GET) && !empty($_GET['c'])) : ?>

    <?php if($item['id'] == $_GET['c']) : ?> 
        <?php if(!($item['img']=="")) : ?>
            <img src="<?=$item['img']?>">
        <?php else : ?> 
            <img src="https://previews.123rf.com/images/grgroup/grgroup1704/grgroup170402985/76354132-monochrome-sketch-silhouette-of-drink-cocktail-glass-vermouth-vector-illustration.jpg">
        <?php endif; ?>
        <h2>Name : <?=$item['name']?></h2>
        <br>
        <br>
        <p>Base spirit : <?=$item['base_spirit'] == 0 ? 'Rum' : ($item['base_spirit'] == 1 ? 'Vodka' : 'Tequila') ?></p>
        <p>Alcohol content : <?=$item['alcohol_content']?>%vol</p>
        <p>Ingredients : <?=$item['ingredients']?></p>
        <p>Comments : </p>
        <div class="comments">
        <?php if(!empty($item['comments'])) : ?>
            <p><?=$item['comments']?></p>
        <?php else : ?>
            <p>There are no comments for this cocktail so far.</p>
        <?php endif; ?>
        </div>
    <?php endif; ?>
    <?php endif; ?>
<?php endforeach; ?>
</div>