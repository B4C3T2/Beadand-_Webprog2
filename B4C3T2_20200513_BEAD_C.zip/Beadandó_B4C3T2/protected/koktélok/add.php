<?php if(!isset($_SESSION['permission']) || $_SESSION['permission'] < 2) : ?>
	<h1>Page access is forbidden!</h1>
<?php else : ?>

	<?php
	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['addCocktail'])) {
		$postData = [
			'name' => $_POST['name'],
			'base_spirit' => $_POST['base_spirit'],
			'alcohol_content' => $_POST['alcohol_content'],
			'ingredients' => $_POST['ingredients'],
			'img' => $_POST['img']
		];

		if(empty($postData['name']) || $postData['base_spirit'] < 0 && $postData['base_spirit'] > 2|| empty($postData['alcohol_content']) || empty($postData['ingredients'])) {
			echo "Missing datas!";
		} else {
			$query = "INSERT INTO cocktails (name, base_spirit, alcohol_content, ingredients, img) VALUES (:name, :base_spirit, :alcohol_content, :ingredients, :img)";
			$params = [
				':name' => $postData['name'],
				':base_spirit' => $postData['base_spirit'],
				':alcohol_content' => $postData['alcohol_content'],
				':ingredients' => $postData['ingredients'],
				':img' => $postData['img']
			];
			require_once DATABASE_CONTROLLER;
			if(!executeDML($query, $params)) {
				echo "Hiba az adatbevitel során!";
			} header('Location: index.php');
		}
	}
	?>

	<form method="post">
		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailName">Name</label>
				<input type="text" class="form-control" id="cocktailName" name="name">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
		    	<label for="cocktailBasespirit">Base spirit</label>
		    	<select class="form-control" id="cocktailBasespirit" name="base_spirit">
		      		<option value="0">Rum</option>
		      		<option value="1">Vodka</option>
		      		<option value="2">Tequila</option>
		    	</select>
		  	</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailAlcoholcontent">Alcohol content</label>
				<input type="text" class="form-control" id="cocktailAlcoholcontent" name="alcohol_content">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailIngredients">Ingredients</label>
				<input type="text" class="form-control" id="cocktailIngredients" name="ingredients">
			</div>
		</div>

		<div class="form-row">
			<div class="form-group col-md-12">
				<label for="cocktailImg">Image web url</label>
				<input type="text" class="form-control" id="cocktailImg" name="img" value="EMPTY">
			</div>
		</div>

		<button type="submit" class="btn btn-primary" name="addCocktail">Add Cocktail</button>
	</form>
<?php endif; ?>