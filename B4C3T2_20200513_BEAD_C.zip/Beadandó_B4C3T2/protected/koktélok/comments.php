<?php if(!isset($_SESSION['permission']) || $_SESSION['permission'] < 1) : ?>
	<h1>You don't have the permission to do that!</h1>
<?php else :
	if(!array_key_exists('c', $_GET) || empty($_GET['c'])) : 
		header('Location: index.php');
	else: 

	if($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['CommentCocktail'])) {
	$postData = [
		'id' => $_POST['cocktailid'],
		'comments' => $_POST['comments']
	];
	if($postData['id'] != $_GET['c']) {
		echo "Error during commenting!";
	} else {
			$query2 = "UPDATE cocktails SET comments = :comments WHERE id = :id";
			$query1 = "SELECT id, comments FROM cocktails WHERE id = :id";
			$params1 = [':id' => $_GET['c']];
			require_once DATABASE_CONTROLLER;
			$actual = getRecord($query1, $params1);
			$params2 = [
				':comments' => $actual['comments']."<br>".$postData['comments'],
				':id' => $postData['id']
			];
			if(!executeDML($query2, $params2)) {
				echo "Error during commenting!";
		} header('Location: ?P=list_cocktails');
	}
}


	$query = "SELECT id, comments FROM cocktails WHERE id = :id";
	$params = [':id' => $_GET['c']];
	require_once DATABASE_CONTROLLER;
	$cocktail = getRecord($query, $params);
	if(empty($cocktail)) :
		header('Location: index.php');
	else : ?>
		<form method="post">
		<input type="hidden" name="cocktailid" value="<?=$cocktail['id'] ?>">
		<div class="md-form md-outline">
			<label for="form75">Comments</label>
    		<textarea id="form75" class="md-textarea form-control" rows="5" name="comments"></textarea>
		</div>
		<br>
		<button type="submit" class="btn btn-primary" name="CommentCocktail">Save comment</button>
		</form>
	<?php endif; ?>
	<?php endif; ?>
<?php endif; ?>