-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Gép: 127.0.0.1:3306
-- Létrehozás ideje: 2020. Máj 13. 12:45
-- Kiszolgáló verziója: 10.4.10-MariaDB
-- PHP verzió: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Adatbázis: `beadando`
--

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `cocktails`
--

DROP TABLE IF EXISTS `cocktails`;
CREATE TABLE IF NOT EXISTS `cocktails` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) COLLATE utf8_hungarian_ci NOT NULL,
  `base_spirit` tinyint(4) NOT NULL,
  `alcohol_content` int(11) NOT NULL,
  `ingredients` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `comments` text COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  `img` varchar(1000) COLLATE utf8_hungarian_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `cocktails`
--

INSERT INTO `cocktails` (`id`, `name`, `base_spirit`, `alcohol_content`, `ingredients`, `comments`, `img`) VALUES
(3, 'Screwdriver', 1, 12, 'vodka, orange juice', '', 'https://www.ndtv.com/cooks/images/screwdriver-620.png'),
(9, 'Vodka martini', 1, 36, 'vodka, dry vermouth', '', 'https://www.jamieoliver.com/drinks-tube/wp-content/uploads/2014/06/Vodka-Martini.jpg'),
(10, 'Mojito', 0, 15, 'rum, lime, mint leaves, simple sirup, soda', '', 'https://chow-hub.com/wp-content/uploads/2018/06/How-To-Make-A-Mojito-Recipe-Cocktail-Fresh-Honey-3.jpg'),
(12, 'Adios Motherf*cker', 0, 30, 'rum, tequila, vodka, gin, tiple sec, blue curacao, lime, lemon-lime soda', '', ''),
(13, 'Tequila sunrise', 2, 12, 'tequila, brenadine, orange juice', '', 'https://winedharma.com/sites/winedharma.com/files/imagecache/auto-768/story/1600-tequila-sunrise-cocktail-original-recipe-cocktail-tequila-orange-juice-grenadine.jpg');

-- --------------------------------------------------------

--
-- Tábla szerkezet ehhez a táblához `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) COLLATE utf8_hungarian_ci NOT NULL,
  `last_name` varchar(64) COLLATE utf8_hungarian_ci NOT NULL,
  `email` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `password` varchar(250) COLLATE utf8_hungarian_ci NOT NULL,
  `permission` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_hungarian_ci;

--
-- A tábla adatainak kiíratása `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `password`, `permission`) VALUES
(1, 'József', 'Heim', 'mrszenya@gmail.com', '85136c79cbf9fe36bb9d05d0639c70c265c18d37', 2),
(3, 'root', 'root', 'root@root.com', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 2);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
